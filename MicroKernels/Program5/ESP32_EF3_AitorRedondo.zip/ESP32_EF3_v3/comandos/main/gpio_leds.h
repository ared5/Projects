/*
 * gpio_leds.h
 *
 *  Created on: 9 dic. 2020
 *      Author: jcgar
 */

#ifndef GPIO_LEDS_H_
#define GPIO_LEDS_H_


#define BLINK_GPIO_1 0
#define BLINK_GPIO_2 2
#define BLINK_GPIO_3 4


#endif /* GPIO_LEDS_H_ */
