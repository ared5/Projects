#ifndef GPIO_PUSH_H_
#define GPIO_PUSH_H_

#define GPIO_INPUT_IO_0     26 // Solución EF32: Definir boton GPIO26
#define GPIO_INPUT_IO_27    27 // Solución EF32: Definir boton GPIO27

#define GPIO_INPUT_PIN_SEL  ((1ULL<<GPIO_INPUT_IO_0) | (1ULL<<GPIO_INPUT_IO_27)) // Solución EF32: Configuracion botones
#define ESP_INTR_FLAG_DEFAULT 0 // Solución EF32: Flag de interrupcion

extern int firstTimeBoton; // Solución EF32: Variable global utilizada en console_example_main.c y en miscomandos.h. Probablemente sustituible por IPC

#endif /* GPIO_PUSH_H_ */
