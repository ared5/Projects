/*
 * miscomandos.h
 *
 *  Created on: 9 dic. 2020
 *      Author: jcgar
 */
#include "freertos/timers.h"

#ifndef MAIN_MISCOMANDOS_H_
#define MAIN_MISCOMANDOS_H_


#define FLAG_BIT (1 << 0) // Solución EF32: Definir flag

void init_MisComandos(void);

extern TimerHandle_t timerhandle5s;  // Solución EF32: El timer de 5 segundos se utiliza tambien en console_example_main.c para parar la alarma con el pulsador derecho

#endif /* MAIN_MISCOMANDOS_H_ */
