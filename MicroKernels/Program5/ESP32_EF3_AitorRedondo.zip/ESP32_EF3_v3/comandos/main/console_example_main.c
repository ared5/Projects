/* Console example

   This example code is in the Public Domain (or CC0 licensed, at your option.)

   Unless required by applicable law or agreed to in writing, this
   software is distributed on an "AS IS" BASIS, WITHOUT WARRANTIES OR
   CONDITIONS OF ANY KIND, either express or implied.
*/

#include <stdio.h>
#include <string.h>
#include "esp_system.h"
#include "esp_log.h"
#include "esp_console.h"
#include "esp_chip_info.h"
#include "esp_vfs_dev.h"
#include "driver/uart.h"
#include "linenoise/linenoise.h"
#include "argtable3/argtable3.h"
#include "cmd_system.h"
#include "miscomandos.h"
#include "esp_vfs_fat.h"
#include "driver/adc.h"
#include "gpio_leds.h" // Solución EF32: Añadido para LEDs
#include "gpio_push.h" // Solución EF32: Añadido para pulsadores
#include "freertos/semphr.h" // Solución EF32: Añadido para semaforos
#include <rom/ets_sys.h>

#include "freertos/event_groups.h" // Solución EF32: Añadido para eventos de flags
//#include "nvs.h"
//#include "nvs_flash.h"

int firstTimeBoton = 2; // Solución EF32: Variable utilizada para gestion de ALARMA por pantalla

static const char* TAG = "example";
//static SemaphoreHandle_t semaforoBoton;
extern EventGroupHandle_t FlagsEventos; // Solución EF32: Eventos de flags para activar en miscomandos.c
TimerHandle_t timerhandle5s; // Solución EF32: Timer de 5 segundos utilizado para pararlo al pulsar boton derecho

/* Console command history can be stored to and loaded from a file.
 * The easiest way to do this is to use FATFS filesystem on top of
 * wear_levelling library.
 */
#if CONFIG_STORE_HISTORY

#define MOUNT_PATH "/data"
#define HISTORY_PATH MOUNT_PATH "/history.txt"

static void initialize_filesystem(void)
{
    static wl_handle_t wl_handle;
    const esp_vfs_fat_mount_config_t mount_config = {
            .max_files = 4,
            .format_if_mount_failed = true
    };
    esp_err_t err = esp_vfs_fat_spiflash_mount(MOUNT_PATH, "storage", &mount_config, &wl_handle);
    if (err != ESP_OK) {
        ESP_LOGE(TAG, "Failed to mount FATFS (%s)", esp_err_to_name(err));
        return;
    }
}
#endif // CONFIG_STORE_HISTORY


static void initialize_console(void)
{
    /* Drain stdout before reconfiguring it */
    fflush(stdout);
    fsync(fileno(stdout));

    /* Disable buffering on stdin */
    setvbuf(stdin, NULL, _IONBF, 0);

    /* Minicom, screen, idf_monitor send CR when ENTER key is pressed */
    esp_vfs_dev_uart_set_rx_line_endings(ESP_LINE_ENDINGS_CR);
    /* Move the caret to the beginning of the next line on '\n' */
    esp_vfs_dev_uart_set_tx_line_endings(ESP_LINE_ENDINGS_CRLF);

    /* Configure UART. Note that REF_TICK is used so that the baud rate remains
     * correct while APB frequency is changing in light sleep mode.
     */
    const uart_config_t uart_config = {
            .baud_rate = CONFIG_ESP_CONSOLE_UART_BAUDRATE,
            .data_bits = UART_DATA_8_BITS,
            .parity = UART_PARITY_DISABLE,
            .stop_bits = UART_STOP_BITS_1,
            .source_clk = UART_SCLK_REF_TICK,
    };
    /* Install UART driver for interrupt-driven reads and writes */
    ESP_ERROR_CHECK( uart_driver_install(CONFIG_ESP_CONSOLE_UART_NUM,
            256, 0, 0, NULL, 0) );
    ESP_ERROR_CHECK( uart_param_config(CONFIG_ESP_CONSOLE_UART_NUM, &uart_config) );

    /* Tell VFS to use UART driver */
    esp_vfs_dev_uart_use_driver(CONFIG_ESP_CONSOLE_UART_NUM);

    /* Initialize the console */
    esp_console_config_t console_config = {
            .max_cmdline_args = 8,
            .max_cmdline_length = 256,
#if CONFIG_LOG_COLORS
            .hint_color = atoi(LOG_COLOR_CYAN)
#endif
    };
    ESP_ERROR_CHECK( esp_console_init(&console_config) );

    /* Configure linenoise line completion library */
    /* Enable multiline editing. If not set, long commands will scroll within
     * single line.
     */
    linenoiseSetMultiLine(1);

    /* Tell linenoise where to get command completions and hints */
    linenoiseSetCompletionCallback(&esp_console_get_completion);
    linenoiseSetHintsCallback((linenoiseHintsCallback*) &esp_console_get_hint);

    /* Set command history size */
    linenoiseHistorySetMaxLen(100);

#if CONFIG_STORE_HISTORY
    /* Load command history from filesystem */
    linenoiseHistoryLoad(HISTORY_PATH);
#endif
}

void initGPIO(void)
{
	// Solución EF32: Configura los pines del LED tricolor como salida.

	gpio_reset_pin(BLINK_GPIO_1);
	gpio_reset_pin(BLINK_GPIO_2);
	gpio_reset_pin(BLINK_GPIO_3);
	/* Set the GPIO as a push/pull output */
	gpio_set_direction(BLINK_GPIO_1, GPIO_MODE_OUTPUT);
	gpio_set_direction(BLINK_GPIO_2, GPIO_MODE_OUTPUT);
	gpio_set_direction(BLINK_GPIO_3, GPIO_MODE_OUTPUT);
}

// Solución EF32: Interrupcion para pulsador izquierdo (activacion de alarma por pulsacion de boton)
static void IRAM_ATTR gpio_isr_handler(void* arg)
{
	firstTimeBoton = 0; // Solución EF32: Variable para no estorbarse con el resto de funcionalidades
	uint32_t gpio_num = (uint32_t) arg;
	BaseType_t xHigherPriorityTaskWoken=pdFALSE;
	ets_delay_us(5000); //Antirrebote SW "cutre". Por simplicidad lo dejamos as�
	if (gpio_get_level(gpio_num)==0)	//Hemos configurado flanco de bajada, comprobamos si el nivel vale 0.
	{
		xEventGroupSetBitsFromISR(FlagsEventos, FLAG_BIT, &xHigherPriorityTaskWoken); // Solución EF32: Activamos flag desde ISR
	}
	if (xHigherPriorityTaskWoken) portYIELD_FROM_ISR();
}

// Solución EF32: Función de interrupción para el GPIO 27 (parar la alarma)
static void IRAM_ATTR gpio_isr_handler_27(void* arg)
{
	firstTimeBoton = 2;
	xTimerStop(timerhandle5s, portMAX_DELAY); // Solución EF32: Paramos el mensaje ALARMA por pantalla parando el temporizador
	uint32_t gpio_num = (uint32_t)arg;
	BaseType_t xHigherPriorityTaskWoken = pdFALSE;
	ets_delay_us(5000); // Antirrebote SW "cutre". Por simplicidad lo dejamos así
	if (gpio_get_level(gpio_num) == 0) {
		xEventGroupClearBitsFromISR (FlagsEventos, FLAG_BIT); // Solución EF32: Eliminamos flag de alarma
	}
	if (xHigherPriorityTaskWoken) {
		portYIELD_FROM_ISR();
	}
}

// Solución EF32: Funcion para configurar los pulsadores
void initGPIOpush (void)
{
	gpio_config_t io_conf;

	// Solución EF32:  Configurar el GPIO 26 (GPIO_INPUT_IO_0) como un pulsador con interrupción en flanco de bajada
	io_conf.intr_type = GPIO_INTR_NEGEDGE;
	io_conf.pin_bit_mask = GPIO_INPUT_PIN_SEL;
	io_conf.mode = GPIO_MODE_INPUT;
	io_conf.pull_up_en = 1;
	io_conf.pull_down_en = 0;
	gpio_config(&io_conf);

	// Solución EF32: Instalar el servicio de ISR de GPIO
	gpio_install_isr_service(ESP_INTR_FLAG_DEFAULT);

	// Solución EF32:  Añadir el manejador de ISR para el GPIO 26
	gpio_isr_handler_add(GPIO_INPUT_IO_0, gpio_isr_handler, (void*)GPIO_INPUT_IO_0);

	// Solución EF32: Añadir el manejador de ISR para el GPIO 27
	gpio_isr_handler_add(GPIO_INPUT_IO_27, gpio_isr_handler_27, (void*)GPIO_INPUT_IO_27);
}


void app_main(void)
{
	FlagsEventos = xEventGroupCreate(); // Solución EF32: Inicializamos flag
	if( FlagsEventos == NULL )
	{
	        while(1);
	}

	initGPIO(); // Solución EF32: Inicializa los pines de salida
	initGPIOpush(); // Solución EF32: Inicializa pulsadores

#if CONFIG_STORE_HISTORY
    initialize_filesystem();
    ESP_LOGI(TAG, "Command history enabled");
#else
    ESP_LOGI(TAG, "Command history disabled");
#endif

    //inicializa la consola
    initialize_console();

    /* Register commands */
    esp_console_register_help_command();
    register_system();
    init_MisComandos();

    //Inicializa el ADC... 12bits con rango de 3,6V (atenuaci�n 11dB) [Utilizando las FUNCIONES LEGACY (compatibilidad hacia atras)]
    adc1_config_width(ADC_WIDTH_BIT_12);
    adc1_config_channel_atten(ADC_CHANNEL_6, ADC_ATTEN_DB_11); //GPIO34 if ADC1. Rango de 3,6 V


    /* Prompt to be printed before each line.
     * This can be customized, made dynamic, etc.
     */
    const char* prompt = LOG_COLOR_I "esp32> " LOG_RESET_COLOR;

    printf("\n"
           "This is an example of ESP-IDF console component.\n"
           "Type 'help' to get the list of commands.\n"
           "Use UP/DOWN arrows to navigate through command history.\n"
           "Press TAB when typing command name to auto-complete.\n");

    /* Figure out if the terminal supports escape sequences */
    int probe_status = linenoiseProbe();
    if (probe_status) { /* zero indicates success */
        printf("\n"
               "Your terminal application does not support escape sequences.\n"
               "Line editing and history features are disabled.\n"
               "On Windows, try using Putty instead.\n");
        linenoiseSetDumbMode(1);
#if CONFIG_LOG_COLORS
        /* Since the terminal doesn't support escape sequences,
         * don't use color codes in the prompt.
         */
        prompt = "esp32> ";
#endif //CONFIG_LOG_COLORS
    }

    /* Main loop */
    while(true) {
        /* Get a line using linenoise.
         * The line is returned when ENTER is pressed.
         */
        char* line = linenoise(prompt);
        if (line == NULL) { /* Ignore empty lines */
            continue;
        }
        /* Add the command to the history */
        linenoiseHistoryAdd(line);
#if CONFIG_STORE_HISTORY
        /* Save command history to filesystem */
        linenoiseHistorySave(HISTORY_PATH);
#endif

        /* Try to run the command */
        int ret;
        esp_err_t err = esp_console_run(line, &ret);
        if (err == ESP_ERR_NOT_FOUND) {
            printf("Unrecognized command\n");
        } else if (err == ESP_ERR_INVALID_ARG) {
            // command was empty
        } else if (err == ESP_OK && ret != ESP_OK) {
            printf("Command returned non-zero error code: 0x%x (%s)\n", ret, esp_err_to_name(ret));
        } else if (err != ESP_OK) {
            printf("Internal error: %s\n", esp_err_to_name(err));
        }
        /* linenoise allocates line buffer on the heap, so need to free it */
        linenoiseFree(line);
    }
}
