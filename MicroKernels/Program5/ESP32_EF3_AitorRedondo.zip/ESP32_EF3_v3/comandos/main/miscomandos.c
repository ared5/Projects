/*
 * miscomandos.c
 *
 *  Created on: 9 dic. 2020
 *      Author: jcgar
 */

#include <stdio.h>
#include <string.h>
#include <ctype.h>
#include "esp_log.h"
#include "esp_console.h"
#include "esp_system.h"
#include "esp_sleep.h"
#include "esp_spi_flash.h"
#include "esp_flash.h"
#include "driver/rtc_io.h"
#include "driver/uart.h"
#include "driver/gpio.h"
#include "argtable3/argtable3.h"
#include "freertos/FreeRTOS.h"
#include "freertos/task.h"
#include "miscomandos.h"
#include "sdkconfig.h"
#include "driver/adc.h"
#include "gpio_leds.h" // Solución EF32: Añadido para LEDs
#include "freertos/timers.h" // Solución EF32: Añadido para timers
#include "gpio_push.h" // Solución EF32: Añadido para pulsadores
#include "freertos/semphr.h" // Solución EF32: Añadido para semaforos
#include "freertos/event_groups.h" // Solución EF32: Añadido para eventos de flags


#define ALARM_THRESHOLD 2.5 // Solución EF32: Umbral de activacion alarma (en voltios).

// Solución EF31: Definir la estructura de datos a mandar a los LEDs
typedef struct {
	uint16_t color;
    uint16_t veces;
    float frecuencia;
} DataBlink;

static QueueHandle_t BlinkQueue; // Solución EF31: Definir cola para comandos de los LEDs
static TimerHandle_t timerhandle10ms; // Solución EF32: Timer para medir el potenciometro cada 10ms
extern TimerHandle_t timerhandle5s; // Solución EF32: Timer para mostrar el mensaje "ALARMA" cada 5 segundos
EventGroupHandle_t FlagsEventos; // Solución EF32: Grupo de eventos para encender/apagar la alarma (pulsador y comandos)
static SemaphoreHandle_t semaforoMeasure; // Solución EF32: Semaforo para la medicion del potenciometro
_Bool firstTime=0; // Solución EF32: Variable global para que no se estorben los diferentes mecanismos de alarma. Mejorable con IPC (mutex?)

static int Cmd_led(int argc, char **argv)
{
	if (argc == 1)
	{
		//Si los par�metros no son suficientes, muestro la ayuda
		printf(" LED [on|off]\r\n");
	}
	else
	{
		/* chequeo el parametro */
		if (0==strncmp( argv[1], "on",2))
		{
			printf("Enciendo el LED\r\n");
			gpio_set_level(BLINK_GPIO_1, 1);
		}
		else if (0==strncmp( argv[1], "off",3))
		{
			printf("Apago el LED\r\n");
			gpio_set_level(BLINK_GPIO_1, 0);
		}
		else
		{
			//Si el par�metro no es correcto, muestro la ayuda
			printf(" LED [on|off]\r\n");
		}

	}
    return 0;

}

static void register_Cmd_led(void)
{
    const esp_console_cmd_t cmd = {
        .command = "led",
        .help = "Enciende y apaga el led rojo",
        .hint = NULL,
        .func = &Cmd_led,
    };
    ESP_ERROR_CHECK( esp_console_cmd_register(&cmd) );
}

static int Cmd_blink(int argc, char **argv)
{
	// Solución EF31: Definir estructura de datos para mandar a los LEDs
	typedef struct {
		uint16_t color;
		uint16_t veces;
		float frecuencia;
	} DataBlink;

	DataBlink data; // Solución EF31: Crear data como tipo de datos DataBlink

	if (argc != 4)
	{
		//Si los parámetros no son suficientes, se muestra la ayuda
		printf(" blink  [red|green|blue] [veces] [frecuencia]\r\n");
	}
	else
	{
		// Solución EF31: Almacenar los  datos recibidos en la estructura data
		data.veces = strtoul(argv[2],NULL,10);
		data.frecuencia = strtoul(argv[3],NULL,10);

		//se comprueban los valores de los parámetros aquí falta el led
		if ((data.veces<=0)||(data.frecuencia<=0))
		{
			//Si los parámetros no son correctos, se muestra la ayuda
			printf("  blink  [red|green|blue] [veces] [frecuencia]\r\n");

		}
		else
		{
			// Solución EF31: Escribir que datos de color, veces y frecuencia se han introducido
			printf(" %s %d %f \r\n",argv[1], (int)data.veces,data.frecuencia);

			// Solución EF31: Si el color a encender es el rojo, enviamos un 0
			if (0==strncmp( argv[1], "red",3)){
				data.color = 0; // Rojo
			}
			// Solución EF31: Si el color a encender es el verde, enviamos un 1
			else if (0==strncmp( argv[1], "green",5)){
			data.color = 1; // Verde
			}
			// Solución EF31: Si el color a encender es el azul, enviamos un 2
			else if (0==strncmp( argv[1], "blue",4)){
				data.color = 2; // Azul
			}
			// Solución EF31: ...Podriamos añadir mas comandos con mas numeros

			// Solución EF31: Enviamos a la cola los datos
			xQueueSend(BlinkQueue, &data, portMAX_DELAY);
		}
	}
	return 0;
}

// Solución EF31: Creo una funcion para el encendido y apagado de los LEDs
static void LEDsOnOff( void *pvParameters )
{
	// Solución EF31: Defino el mismo tipo de estructura que tiene lo que hemos enviado de Blink
	typedef struct {
		uint16_t color;
		uint16_t veces;
		float frecuencia;
	} DataBlink;

	DataBlink data_recibido;
	uint16_t i; // Solución EF31: Variable i para hacer la parte de veces a encender

	while(1) {
		// Solución EF31: Recibimos los datos de la cola
		xQueueReceive(BlinkQueue, &data_recibido, portMAX_DELAY);

		// Solución EF31: Si el dato color corresponde con ROJO
		if (data_recibido.color == 0)
		{
			//Solucion EC31: Enciendo y apago las veces determinadas y a la frecuencia determinada
			for (i = 0; i < data_recibido.veces; i++) {
				/* Blink off (output low) */
				gpio_set_level(BLINK_GPIO_1, 1);
				vTaskDelay((1/data_recibido.frecuencia)*configTICK_RATE_HZ);
				/* Blink on (output high) */
				gpio_set_level(BLINK_GPIO_1, 0);
				vTaskDelay((1/data_recibido.frecuencia)*configTICK_RATE_HZ);
			}
		}
		// Solución EF31: Si el dato color corresponde con VERDE
		else if (data_recibido.color == 1){
			//Solucion EC31: Enciendo y apago las veces determinadas y a la frecuencia determinada
			for (i = 0; i < data_recibido.veces; i++) {
				/* Blink off (output low) */
				gpio_set_level(BLINK_GPIO_2, 1);
				vTaskDelay((1/data_recibido.frecuencia)*configTICK_RATE_HZ);
				/* Blink on (output high) */
				gpio_set_level(BLINK_GPIO_2, 0);
				vTaskDelay((1/data_recibido.frecuencia)*configTICK_RATE_HZ);
			}
		}
		// Solución EF31: Si el dato color corresponde con AZUL
		else if (data_recibido.color == 2){
			for (i = 0; i < data_recibido.veces; i++) {
				/* Blink off (output low) */
				gpio_set_level(BLINK_GPIO_3, 1);
				vTaskDelay((1/data_recibido.frecuencia)*configTICK_RATE_HZ);
				/* Blink on (output high) */
				gpio_set_level(BLINK_GPIO_3, 0);
				vTaskDelay((1/data_recibido.frecuencia)*configTICK_RATE_HZ);
			}
		}
		// Solución EF31: Si el dato color no corresponde con ninguno
		else{
			printf(" Prueba de nuevo [red|green|blue]\r\n");
		}
	}
}

static void register_Cmd_blink(void)
{
    const esp_console_cmd_t cmd = {
        .command = "blink",
        .help = "Hace parpadear el LED [red|green|blue]",
        .hint = NULL,
        .func = &Cmd_blink,
    };
    ESP_ERROR_CHECK( esp_console_cmd_register(&cmd) );
}

static int Cmd_adcRead(int argc, char **argv)
{
	int muestra;
	float voltaje;
	muestra=adc1_get_raw(ADC_CHANNEL_6); // Solución EF32: Toma la muestra
	voltaje=(float)muestra*3.6/4096.0;	// Solución EF32: Pasa a voltios (muestra de 12 bits con rango de 3,6V)
	printf (" ADC RAW: %d Volt: %f \r\n",muestra,voltaje);
	return 0;
}

// Solución EF32: Timer para medir el potenciometro cada 10ms
void vTimerAlarmCallback ( TimerHandle_t pxTimer ){

	int muestra = adc1_get_raw(ADC_CHANNEL_6); // Solución EF32: Toma la muestra;
	float voltaje=(float)muestra*3.6/4096.0;   // Solución EF32: Pasa a voltios (muestra de 12 bits con rango de 3,6V);

//	printf (" ADC RAW: %d Volt: %f \r\n",muestra,voltaje); // Solución EF32: Si queremos ver lo que mide cada 10ms por pantalla, descomentamos esto
	if (voltaje > ALARM_THRESHOLD){ // Solución EF32: Si el voltaje medido es mayor al threshold definido arriba...
		xSemaphoreGive(semaforoMeasure); // Solución EF32: ... activamos el semaforoMeasure
	}
	else{
		firstTime = 0; // Solución EF32: Sino ponemos esta variable a 0 para que no se estorben el resto de activaciones de alarma (mejorable con IPC)
		if ((firstTimeBoton == 0) || (firstTimeBoton == 1) || (firstTimeBoton == 3)) { // Solución EF32: En caso de que cualquiera de los otros casos este activando la alarma...
			return; // Solución EF32: ... no se desactiva el timer para poder seguir mostrando el mensaje "ALARMA" por pantalla
		}
	    xTimerStop(timerhandle5s, portMAX_DELAY); // Solución EF32: En caso de que ninguno de los activadores este activo, paramos timer de muestra de mensaje "ALARMA"
	}
}

// Solución EF32: Timer para mostrar el mensaje ALARMA por pantalla cada 5 segundos
void vTimerAlarmPrintCallback ( TimerHandle_t pxTimer ){
	printf (" ALARMA \r\n"); // Solución EF32: Mostramos el mensaje ALARMA por pantalla
}

// Solución EF32: Tarea que utiliza el semaforoMeasure para activar la alarma
static void measureTurnOnAlarm(void *pvParameters) {
	while (1) {
		// Solución EF32: Espera a que se active el semaforo
		xSemaphoreTake(semaforoMeasure, portMAX_DELAY);
		if (firstTime == 0) { // Solución EF32: Si es la primera vez que se ejecuta...
			printf (" ALARMA \r\n"); // Solución EF32: ...mostramos mensaje de alarma...
			xTimerStart(timerhandle5s, portMAX_DELAY); // Solución EF32: ...activamos timer para mostrar por pantalla ALARMA
			firstTime = 1; // Solución EF32: ...hacemos que no se este reiniciando continuamente el timer de 5 segundos
		}
		// Solución EF32: Ejecuta el comportamiento de la alarma, 0.25s ON - 0.25s OFF
		gpio_set_level(BLINK_GPIO_1, 1);
		vTaskDelay(0.25 * configTICK_RATE_HZ);
		/* Blink on (output high) */
		gpio_set_level(BLINK_GPIO_1, 0);
		vTaskDelay(0.25 * configTICK_RATE_HZ);
	}
}

// Solución EF32: Tarea para manejar la pulsacion del boton que activa la alarma
static void botonTurnOnAlarm(void *pvParameters) {
	while (1) {
		// Solución EF32: Espera a que el flag se active desde la ISR de console_example_main.c
		xEventGroupWaitBits(FlagsEventos, FLAG_BIT, pdFALSE, pdFALSE, portMAX_DELAY); // Solución EF32: Utiliza FlagsEventos, FLAG_BIT definido en miscomandos.h y no borra el flag al activarse
		if (firstTimeBoton == 0) { // Solución EF32: Igual que antes, si es la primera vez...
			printf (" ALARMA \r\n"); // Solución EF32: ...mostramos mensaje de alarma...
			xTimerStart(timerhandle5s, portMAX_DELAY); // Solución EF32: ...activamos timer para mostrar por pantalla ALARMA
			firstTimeBoton = 1; // Solución EF32: ...hacemos que no se este reiniciando continuamente el timer de 5 segundos

		}
		// Solución EF32: Ejecuta el comportamiento de la alarma, 0.25s ON - 0.25s OFF
		gpio_set_level(BLINK_GPIO_1, 1);
		vTaskDelay(0.25 * configTICK_RATE_HZ);
		/* Blink on (output high) */
		gpio_set_level(BLINK_GPIO_1, 0);
		vTaskDelay(0.25 * configTICK_RATE_HZ);
	}
}

// Solución EF32: Funcion para encender la alarma y tambien para apagarla
static int commandTurnOnOffAlarm (int argc, char **argv)
{
	if (argc == 1) // Solución EF32: Si solo se introduce un argumento...
	{
		// Solución EF32: Si los par�metros no son suficientes, muestro la ayuda
		printf(" alarma  trigger [time] OR alarma stop \r\n");
	}
	else
	{
		// Solución EF32: chequeo el parametro */
		if (0==strncmp( argv[1], "stop",4)) // Solución EF32: Si el comando es para parar la alarma...
		{
			printf(" ALARMA STOP \r\n"); // Solución EF32: Muestro mensaje de parada de alarma
			firstTimeBoton = 2; // Solución EF32: pongo esta variable para que no moleste
			xTimerStop(timerhandle5s, portMAX_DELAY); // Solución EF32: Paro el timer de 5 segundo que hace mostrar ALARMA por pantalla
			xEventGroupClearBits (FlagsEventos, FLAG_BIT); // Solución EF32: Elimino el bit del flag de activacion de alarma
		}
		else if (0==strncmp( argv[1], "trigger",7)) // Solución EF32: Si el comando es para encender la alarma...
		{
			if (argc == 2){ // Solución EF32: Si solo tiene 2 elementos, indico que le falta el tiempo de activacion
				printf("You need to include trigger time \r\n");
			}
			else if (argc == 3){ // Solución EF32: Si tiene todos los elementos necesarios para activar la alarma...
				firstTimeBoton = 1; // Solución EF32: Variable para no molestar al resto
				float delay = strtof(argv[2],NULL); // Solución EF32: La variable argv[2] es el delay que se espera para empeza a activar la alarma
				vTaskDelay(delay* configTICK_RATE_HZ); // Solución EF32: Hago ese delay
				printf(" ALARMA TRIGGER \r\n" ); // Solución EF32: Muestro que se activa por comando trigger
				xTimerStart(timerhandle5s, portMAX_DELAY); // Solución EF32: Y arranco el timer para mostrar por pantalla ALARMA
				xEventGroupSetBits(FlagsEventos, FLAG_BIT); // Solución EF32: Se activa el flag para que se encienda/apague el led en botonTurnOnAlarm
			}
			else{
				printf(" alarma  trigger [time] \r\n"); // Solución EF32: Muestro ayuda en caso de que falte el tiempo de delay de activacion de alarma
			}
		}
		else
		{
			// Solución EF32: Si el parametro no es correcto, muestro la ayuda
			printf(" alarma  trigger [time] OR alarma stop \r\n");
		}
	}
    return 0;
}

// Solución EF32: Defino el comando para activacion de alarma por comando
static void register_Cmd_InitOrStopAlarm(void)
{
    const esp_console_cmd_t cmd = {
        .command = "alarma",
        .help = "Inicia o para la alarma",
        .hint = NULL,
        .func = &commandTurnOnOffAlarm,
    };
    ESP_ERROR_CHECK( esp_console_cmd_register(&cmd) );
}

// Solución EF32: Comando para lectura de dato del potenciometro
static void register_Cmd_adcRead (void)
{
    const esp_console_cmd_t cmd = {
        .command = "adcRead",
        .help = "Lee valores del ADC",
        .hint = NULL,
        .func = &Cmd_adcRead,
    };
    ESP_ERROR_CHECK( esp_console_cmd_register(&cmd) );
}

void init_MisComandos(void)
{
	// Solución EF31: Crear la cola con capacidad para 10 elementos, cada uno del tamaño de sizeof(DataBlink)
	BlinkQueue = xQueueCreate(10, sizeof(DataBlink));
	if (BlinkQueue == NULL) {
		// No se pudo crear la cola
		while (1) {
			// Manejar el error aquí
		}
	}

	// Solución EF32: Definicion del semaforo para medida del potenciometro
	semaforoMeasure = xSemaphoreCreateBinary();
		if( semaforoMeasure == NULL )
		{
			printf("No se pudo crear el semaforo semaforoMeasure");
		}

		// Solución EF32: Crear un temporizador de software cada 0.1 segundos para medicion del potenciometro
	timerhandle10ms = xTimerCreate("Tmr1",0.1*configTICK_RATE_HZ,pdTRUE, ( void * ) 1, vTimerAlarmCallback);
	if (timerhandle10ms==NULL)
		printf("No pude crear el timerhandle10ms");

	xTimerStart(timerhandle10ms,portMAX_DELAY); // Solución EF32: Se inicializa el temporizador de medida potenciometro

	// Solución EF32: Crear un temporizador de software cada 5 segundos para mensaje ALARMA (no se inicializa todavia)
	timerhandle5s = xTimerCreate("Tmr2",5*configTICK_RATE_HZ,pdTRUE, ( void * ) 1, vTimerAlarmPrintCallback);
	if (timerhandle5s==NULL)
		printf("No pude crear el timerhandle5s");

	register_Cmd_led();
	register_Cmd_blink();
	register_Cmd_adcRead();
	register_Cmd_InitOrStopAlarm(); // Solución EF32: se crea el comando

	// Solución EF31: Se crea tarea que se usa para blink
	if (xTaskCreatePinnedToCore( LEDsOnOff, "LEDsOnOff", configMINIMAL_STACK_SIZE, NULL, tskIDLE_PRIORITY+1, NULL, 0 )!=pdPASS)
	{
		printf("No se pudo crear la tarea LEDsOnOff");
	}

	// Solución EF32: Se crea tarea de medida de potenciometro
	if (xTaskCreatePinnedToCore( measureTurnOnAlarm, "measureTurnOnAlarm", configMINIMAL_STACK_SIZE, NULL, tskIDLE_PRIORITY+1, NULL, 0 )!=pdPASS)
	{
		printf("No se pudo crear la tarea measureTurnOnAlarm");
	}

	// Solución EF32: Se crea tarea de pulsacion de boton (en el core 1 para probar)
	if (xTaskCreatePinnedToCore( botonTurnOnAlarm, "botonTurnOnAlarm", configMINIMAL_STACK_SIZE, NULL, tskIDLE_PRIORITY+1, NULL, 1 )!=pdPASS)
		{
			printf("No se pudo crear la tarea botonTurnOnAlarm");
		}
}
