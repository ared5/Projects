#include "guipanel.h"
#include "ui_guipanel.h"

#include <QtSerialPort/qserialportinfo.h>
#include <QMessageBox>

extern "C" {
#include "protocol.h"
}


GUIPanel::GUIPanel(QWidget *parent) :
    QWidget(parent),
    ui(new Ui::GUIPanel)
    , transactionCount(0)
{
    ui->setupUi(this);
    setWindowTitle(tr("Control remoto ESp32"));


    connected=false;

    tcpSocket = new QTcpSocket(this); //Crea un objeto para gestionar la conexion TCP
    //Conecta señales del objeto a slots locales
    connect(tcpSocket, SIGNAL(readyRead()), this, SLOT(readRequest())); //Señal correspondiente a la llegada de datos
    connect(tcpSocket, SIGNAL(error(QAbstractSocket::SocketError)),this, SLOT(PrintError(QAbstractSocket::SocketError))); //Señal que salta cuando hay error
    connect(tcpSocket,SIGNAL(connected()),this,SLOT(conexion_realizada())); //Señal correspondiente al establecimiento de conexion
    connect(tcpSocket,SIGNAL(disconnected()),this,SLOT(desconexion())); //Señal que salta cuando nos desconectamos.

    //Deshabilita los botones hasta que se establezca la conexion
    ui->pingButton->setEnabled(false);
    ui->KnobVerde->setEnabled(false);
    ui->KnobRojo->setEnabled(false);
    ui->KnobAzul->setEnabled(false);
    ui->rojo->setEnabled(false);
    ui->verde->setEnabled(false);
    ui->async->setEnabled(false);
    ui->sondea->setEnabled(false);
    ui->azul->setEnabled(false);
    ui->modo->setEnabled(false);
    ui->start->setEnabled(false);    

    //configura las escalas de las roscas
    ui->KnobRojo->setScale(0.0,1.0);
    ui->KnobVerde->setScale(0.0,1.0);
    ui->KnobAzul->setScale(0.0,1.0);
    ui->KnobRojo->setTotalSteps(100);
    ui->KnobVerde->setTotalSteps(100);
    ui->KnobAzul->setTotalSteps(100);



    //Configuramos la grafica
    ui->grafica->setTitle("Voltímetro");
    ui->grafica->setAxisTitle(QwtPlot::xBottom,"número de muestra");
    ui->grafica->setAxisTitle(QwtPlot::yLeft, "Volt");
    //ui->grafica->axisAutoScale(true); // Con Autoescala
    ui->grafica->setAxisScale(QwtPlot::yLeft, 0, 3.6); // Con escala definida
    ui->grafica->setAutoReplot(false);

    //Creamos una curva y la añadimos a la grafica
    m_curve_1 = new QwtPlotCurve();
    m_curve_1->setPen(QPen(Qt::red));
    m_Grid = new QwtPlotGrid();
    m_Grid->attach(ui->grafica);
    m_curve_1->attach(ui->grafica);

    //Creamos una curva y la añadimos a la grafica
//    m_curve_2 = new QwtPlotCurve();
//    m_curve_2->setPen(QPen(Qt::blue));
//    m_curve_2->attach(ui->grafica);

//    //Creamos una curva y la añadimos a la grafica
//    m_curve_3 = new QwtPlotCurve();
//    m_curve_3->setPen(QPen(Qt::green));
//    m_curve_3->attach(ui->grafica);

    //Inicializadmos los datos que se muestran en la grafica
    for (int i=0; i<NMAX; i++) {
        yVal1[i]=0;
//        yVal2[i]=0;
//        yVal3[i]=0;
        xVal[i]=i;
    }
    m_curve_1->setRawSamples(xVal,yVal1,NMAX);
//    m_curve_2->setRawSamples(xVal,yVal2,NMAX);
//    m_curve_3->setRawSamples(xVal,yVal3,NMAX);
    ui->grafica->replot();
}

GUIPanel::~GUIPanel()
{
    delete ui;
}

//Este slot procesa la llegada de datos por la conexion TCP.
void GUIPanel::readRequest()
{
    TipoPaquete header;

    while(tcpSocket->bytesAvailable()>=sizeof(header))
    {   //Esperamos a tener suficientes datos...
        //Y procesamos lo que nos ha llegado
        tcpSocket->read((char *)&header,sizeof(header));
        switch (header.comando)
        { //Ahora compruebo que me ha llegado
        case COMANDO_PING:
            {
                QMessageBox ventanaPopUp(QMessageBox::Information,tr("Evento"),tr("RESPUESTA A PING RECIBIDA"),QMessageBox::Ok,this,Qt::Popup);
                ventanaPopUp.exec();
            }
            break;

        case COMANDO_SONDEA_BOTONES:
            ui->but1->setChecked(header.parametro.bits.bit0);
            ui->but2->setChecked(header.parametro.bits.bit1);
            break;

        case COMANDO_RECHAZADO:
            {
                QMessageBox ventanaPopUp(QMessageBox::Information,tr("Evento"),tr("ESP32 rechaza el comando %1").arg(header.parametro.value),QMessageBox::Ok,this,Qt::Popup);
                ventanaPopUp.exec();
            }
            break;        
        case COMANDO_ADC_DATA:
            {
                //Actualizamos gráfica correspondiente
                memmove(yVal1,yVal1+1,sizeof(double)*(NMAX-1)); //Desplazamos las muestras hacia la izquierda
                yVal1[NMAX-1]=3.6*(double)header.parametro.adc.channel0/4096.0; //Añadimos el último punto
                ui->lcdNumber->display(header.parametro.adc.channel0);
                m_curve_1->setRawSamples(xVal,yVal1,NMAX);  //Refrescamos..
                ui->grafica->replot();
            }
            break;
        default:
        {
            QMessageBox ventanaPopUp(QMessageBox::Information,tr("Evento"),tr("Hemos recibido algo inesperado"),QMessageBox::Ok,this,Qt::Popup);
            ventanaPopUp.exec();
        }
            break;
        }

    }
}

void GUIPanel::conexion_realizada()
{

    //Si nos conseguimos conectar, habilitamos los botones

    ui->runButton->setEnabled(false);
    ui->statusLabel->setText(tr("Estado: Ejecucion, conectado al puerto %1.")
                         .arg(tcpSocket->peerPort()));
    ui->pingButton->setEnabled(true);
    ui->KnobVerde->setEnabled(true);
    ui->KnobRojo->setEnabled(true);
    ui->KnobAzul->setEnabled(true);
    ui->rojo->setEnabled(true);
    ui->verde->setEnabled(true);
    ui->async->setEnabled(true);
    ui->sondea->setEnabled(true);
    ui->azul->setEnabled(true);
    ui->modo->setEnabled(true);
    ui->start->setEnabled(true);

    connected=true;
}


void GUIPanel::desconexion()
{
    connected=false;
    activateRunButton();
}

void GUIPanel::pingDevice()
{   //Envia el comando de ping
    TipoPaquete header;

     if (connected)
     {
         header.comando=COMANDO_PING;
         header.parametro.value=0;  //Realmente se ignora, pero lo inicializo

         tcpSocket->write((char *)&header,sizeof(header));
     }
}

//Slot asociado al error de comunicacion
void GUIPanel::PrintError(QAbstractSocket::SocketError socketError)
{
    switch (socketError) {
    case QAbstractSocket::RemoteHostClosedError:
        ui->statusLabel->setText(tr("Estado: Conexion perdida"));
        break;
    case QAbstractSocket::HostNotFoundError:
        QMessageBox::information(this, tr("Qt Client"),
                                 tr("The host was not found. Please check the "
                                    "host name and port settings."));
        break;
    case QAbstractSocket::ConnectionRefusedError:
        QMessageBox::information(this, tr("Qt Client"),
                                 tr("The connection was refused by the peer. "
                                    "Make sure the server is running, "
                                    "and check that the host name and port "
                                    "settings are correct."));
        break;
    default:
        QMessageBox::information(this, tr("Qt Client"),
                                 tr("The following error occurred: %1.")
                                 .arg(tcpSocket->errorString()));
    }
    connected=false;
    activateRunButton();
}

//Funcion que vuelve a activar el boton de run y desactiva los demas
void GUIPanel::activateRunButton()
{
    //Activa el boton de run(...)
    ui->runButton->setEnabled(true);

    //Desactiva los demas...
    ui->pingButton->setEnabled(false);
    ui->KnobVerde->setEnabled(false);
    ui->KnobRojo->setEnabled(false);
    ui->KnobAzul->setEnabled(false);
    ui->rojo->setEnabled(false);
    ui->verde->setEnabled(false);
    ui->async->setEnabled(false);
    ui->sondea->setEnabled(false);
    ui->azul->setEnabled(false);
    ui->modo->setEnabled(false);
    ui->start->setEnabled(false);
}

//Slot asociado al boton ping
void GUIPanel::on_pingButton_clicked()
{   //Envia el comando de ping
    pingDevice();
}

//Slot asociado al boton "Run"
void GUIPanel::on_runButton_clicked()
{ 
    tcpSocket->abort();
    tcpSocket->connectToHost(ui->Servidor->text(),ui->puerto->value());
    ui->runButton->setEnabled(false);

}

//Slots asociado a los checkboxes de los LEDs
void GUIPanel::on_rojo_stateChanged(int arg1)
{
    cambiaLEDs();
}

void GUIPanel::on_verde_stateChanged(int arg1)
{
    cambiaLEDs();
}

void GUIPanel::on_azul_toggled(bool checked)
{
    cambiaLEDs();
}
//Funcion que envia el paquete con el estado de los leds
void GUIPanel::cambiaLEDs()
{
    TipoPaquete header;
    int size;

     if (connected)
     {
         header.comando=COMANDO_LED;
         header.parametro.bits.bit0=ui->rojo->isChecked();
         header.parametro.bits.bit1=ui->verde->isChecked();
         header.parametro.bits.bit2=ui->azul->isChecked();

         tcpSocket->write((char *)&header,sizeof(header));
     }
}

//Slots asociado al boton de sondear
void GUIPanel::on_sondea_clicked()
{   //Envia el paquete de sondeo
    TipoPaquete header;
    int size;

     if (connected)
     {
         header.comando=COMANDO_SONDEA_BOTONES;
         header.parametro.value=0;  //Realmente se ignora, pero lo inicializo

         tcpSocket->write((char *)&header,sizeof(header));
     }
}

//Envia el comando indicando el modo de los botones
void GUIPanel::on_async_toggled(bool checked)
{
    TipoPaquete header;
    if (connected)
    {
        header.comando=COMANDO_BOTONES_ASYNC;
        header.parametro.value=checked;
        tcpSocket->write((char *)&header,sizeof(header));
    }
}

//Envia los PWM de las roscas
void GUIPanel::on_KnobRojo_valueChanged(double value)
{

    TipoPaquete header;
    if (connected)
    {
        header.comando=COMANDO_PWM_LEDS;

        header.parametro.pwm.red=(uint8_t) (ui->KnobRojo->value()*0xFF);
        header.parametro.pwm.green=(uint8_t) (ui->KnobVerde->value()*0xFF);
        header.parametro.pwm.blue=(uint8_t) (ui->KnobAzul->value()*0xFF);

        tcpSocket->write((char *)&header,sizeof(header));
    }
}
//Envia los PWM de las roscas
void GUIPanel::on_KnobVerde_valueChanged(double value)
{
    TipoPaquete header;
    if (connected)
    {
        header.comando=COMANDO_PWM_LEDS;

        header.parametro.pwm.red=(uint8_t) (ui->KnobRojo->value()*0xFF);
        header.parametro.pwm.green=(uint8_t) (ui->KnobVerde->value()*0xFF);
        header.parametro.pwm.blue=(uint8_t) (ui->KnobAzul->value()*0xFF);

        tcpSocket->write((char *)&header,sizeof(header));
    }
}
//Envia los PWM de las roscas
void GUIPanel::on_KnobAzul_valueChanged(double value)
{
    TipoPaquete header;
    if (connected)
    {
        header.comando=COMANDO_PWM_LEDS;

        header.parametro.pwm.red=(uint8_t) (ui->KnobRojo->value()*0xFF);
        header.parametro.pwm.green=(uint8_t) (ui->KnobVerde->value()*0xFF);
        header.parametro.pwm.blue=(uint8_t) (ui->KnobAzul->value()*0xFF);

        tcpSocket->write((char *)&header,sizeof(header));
    }
}
//Envia el modo de los pines
void GUIPanel::on_modo_currentIndexChanged(int index)
{
    TipoPaquete header;
    if (connected)
    {
        header.comando=COMANDO_MODO;
        header.parametro.value=index; //Haria falta comprobar que esta dentro de rango...
//        switch (index)
//        {
//                case 0:
//                break;
//                case 1:
//                break;
//        }
        tcpSocket->write((char *)&header,sizeof(header));
    }
}



//Envia la orden de comenzar a muestrear acelerómetros
void GUIPanel::on_start_toggled(bool checked)
{
    TipoPaquete header;
    if (connected)
    {
        if (checked)
        {
            header.comando=COMANDO_ADC_START;
            header.parametro.fvalue=ui->adcfreq->value();
        }
        else
        {
            header.comando=COMANDO_ADC_STOP;
        }
        tcpSocket->write((char *)&header,sizeof(header));
    }
}



// G4B: Implementar rosca para envio DAC
void GUIPanel::on_KnobDAC_valueChanged(double value)
{
    TipoPaquete header;
    if (connected)
    {
        header.comando = COMANDO_DAC_VALUE;
        header.parametro.value = (uint8_t) (ui->KnobDAC->value()/3.3*0xFF); // G4B: Escalar valor para el DAC
        tcpSocket->write((char *)&header, sizeof(header));
    }

}

void GUIPanel::on_KnobMin_valueChanged(double value)
{
    TipoPaquete header;
    if (connected)
    {
        header.comando = COMANDO_UMBRAL_MIN;
        header.parametro.value = (uint16_t) (ui->KnobMin->value()/3.6*4096);
        tcpSocket->write((char *)&header, sizeof(header));
    }

}


void GUIPanel::on_KnobMax_valueChanged(double value)
{
    TipoPaquete header;
    if (connected)
    {
        header.comando = COMANDO_UMBRAL_MAX;
        header.parametro.value = (uint16_t) (ui->KnobMax->value()/3.6*4096);
        tcpSocket->write((char *)&header, sizeof(header));
    }
}


void GUIPanel::on_ArrancarBoton_clicked()
{
    TipoPaquete header;
    //ui->actualizaBoton->setEnabled(true);
    header.parametro.value=1;
    header.comando=COMANDO_ARRANCA_MONITOR;
   tcpSocket->write((char *)&header, sizeof(header));

}


void GUIPanel::on_DetenerBoton_clicked()
{
   TipoPaquete header;
   //ui->actualizaBoton->setEnabled(true);
   header.parametro.value=0;
   header.comando=COMANDO_DETENER_MONITOR;
   tcpSocket->write((char *)&header, sizeof(header));
}


void GUIPanel::on_ResetBoton_clicked()
{
   TipoPaquete header;
   //ui->actualizaBoton->setEnabled(true);
   header.parametro.value=0;
   header.comando=COMANDO_ALARMA;
   tcpSocket->write((char *)&header, sizeof(header));

}




