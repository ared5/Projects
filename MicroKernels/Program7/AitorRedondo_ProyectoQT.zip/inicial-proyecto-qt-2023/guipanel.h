#ifndef GUIPANEL_H
#define GUIPANEL_H

#include <QWidget>
#include <QTcpSocket>

#include <qwt_plot_curve.h>
#include <qwt_plot_grid.h>

#define NMAX 300

namespace Ui {
class GUIPanel;
}

//QT4:QT_USE_NAMESPACE_SERIALPORT

class GUIPanel : public QWidget
{
    Q_OBJECT
    
public:
    //GUIPanel(QWidget *parent = 0);
    explicit GUIPanel(QWidget *parent = 0);
    ~GUIPanel(); // Da problemas
    
private slots:
    //Slots para conexion TCP
    void readRequest();
    void PrintError(QAbstractSocket::SocketError socketError);
    void conexion_realizada();
    void desconexion();

    //Slots botones (creados automaticamente)
    void on_pingButton_clicked();
    void on_runButton_clicked();    
    void on_rojo_stateChanged(int arg1);
    void on_verde_stateChanged(int arg1);

    void on_sondea_clicked();
    void on_async_toggled(bool checked);

    void on_KnobRojo_valueChanged(double value);

    void on_KnobVerde_valueChanged(double value);

    void on_KnobAzul_valueChanged(double value);

    void on_modo_currentIndexChanged(int index);

    void on_azul_toggled(bool checked);
    void on_start_toggled(bool checked);


    void on_KnobDAC_valueChanged(double value);

    void on_KnobMin_valueChanged(double value);

    void on_KnobMax_valueChanged(double value);

    void on_ArrancarBoton_clicked();

    void on_DetenerBoton_clicked();

    void on_ResetBoton_clicked();

private: // funciones privadas
    void pingDevice();
    void activateRunButton();
    void cambiaLEDs();


private:
    Ui::GUIPanel *ui;
    int transactionCount;
    bool connected;
    QTcpSocket *tcpSocket; //Gestiona la conexion TCP
    QByteArray request;

    double xVal[NMAX];
    double yVal1[NMAX];
//    double yVal2[NMAX];
//    double yVal3[NMAX];

    QwtPlotGrid  *m_Grid;
    QwtPlotCurve *m_curve_1;
//    QwtPlotCurve *m_curve_2;
//    QwtPlotCurve *m_curve_3;


};

#endif // GUIPANEL_H
