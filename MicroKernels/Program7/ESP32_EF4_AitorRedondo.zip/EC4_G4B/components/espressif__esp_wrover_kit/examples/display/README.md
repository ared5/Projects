# BSP: Display example

This is a minimalistic display + LVGL graphics library example.
In few function calls it sets up the display and shows Espressif's logo and label.

<a href="https://espressif.github.io/esp-launchpad/?flashConfigURL=https://espressif.github.io/esp-bsp/config.toml&app=display">
    <img alt="Try it with ESP Launchpad" src="https://espressif.github.io/esp-launchpad/assets/try_with_launchpad.png" width="250" height="70">
</a>
