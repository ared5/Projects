Se entrega unicamente el main ya que todo el proyecto ocupa demasiado.

Respecto al G4A, los cambios se han realizado en los archivos (usando comentarios // G4A:):
- tcp_server.c
- gpio_leds.c
- gpio_leds.h

Se ha validado el funcionamiento.
En caso de que vea algo raro, hagamelo saber para enviarle el proyecto completo.

Gracias