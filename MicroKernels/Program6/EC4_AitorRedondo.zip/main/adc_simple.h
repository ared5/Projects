/*
 * adc_simple.h
 *
 *  Created on: 20 nov 2023
 *      Author: jcgar
 */

#ifndef MAIN_ADC_SIMPLE_H_
#define MAIN_ADC_SIMPLE_H_

void adc_simple_init();
int adc_simple_read_raw();
int adc_simple_read_mv();

#endif /* MAIN_ADC_SIMPLE_H_ */
