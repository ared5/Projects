/*
 * miscomandos.h
 *
 *  Created on: 9 dic. 2020
 *      Author: jcgar
 */

#ifndef MAIN_MISCOMANDOS_H_
#define MAIN_MISCOMANDOS_H_

void init_MisComandos(void);

#endif /* MAIN_MISCOMANDOS_H_ */
