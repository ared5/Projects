/*
 * tcp_server.h
 *
 *  Created on: 15 dic. 2020
 *      Author: jcgar
 */

#ifndef MAIN_TCP_SERVER_H_
#define MAIN_TCP_SERVER_H_


void initTCPServer (void);


#endif /* MAIN_TCP_SERVER_H_ */
